var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./DynamicalabsPicklistWithSearch/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./DynamicalabsPicklistWithSearch/index.ts":
/*!*************************************************!*\
  !*** ./DynamicalabsPicklistWithSearch/index.ts ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.DynamicalabsPicklistWithSearch = void 0;\n\nvar DynamicalabsPicklistWithSearch =\n/** @class */\nfunction () {\n  function DynamicalabsPicklistWithSearch() {}\n\n  DynamicalabsPicklistWithSearch.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _a, _b, _c;\n\n    this.context = context;\n    this.isRequired = [1, 2].indexOf(((_a = context.parameters.OptionValue.attributes) === null || _a === void 0 ? void 0 : _a.RequiredLevel) || 0) > -1;\n    this.options = this.isRequired ? [] : [{\n      Value: null,\n      Label: \"--Select--\"\n    }];\n    this.options = this.options.concat(((_b = context.parameters.OptionValue.attributes) === null || _b === void 0 ? void 0 : _b.Options.map(function (m) {\n      return {\n        Label: m.Label,\n        Value: m.Value\n      };\n    })) || []);\n    this.selectedOption = {\n      Value: context.parameters.OptionValue.raw,\n      Label: context.parameters.OptionValue.raw !== null ? ((_c = this.options.find(function (f) {\n        return f.Value === context.parameters.OptionValue.raw;\n      })) === null || _c === void 0 ? void 0 : _c.Label) || \"Unknown option:\" + context.parameters.OptionValue.raw + \" \" : \"--Select--\"\n    };\n    this.notifyOutputChangedDelegate = notifyOutputChanged;\n    this.container = container;\n    this.container.addEventListener(\"keydown\", this.onKeyPressContainer.bind(this));\n    this.container.classList.add(\"dnl-option-container\");\n    this.initSearchInput();\n    this.initSelectedItem();\n    this.initSearchButton();\n    this.initDropDownContainer();\n    this.renderSelected();\n    window.addEventListener('resize', this.hideDropDownContainer.bind(this));\n    window.addEventListener('click', this.hideDropDownContainer.bind(this));\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.updateView = function (context) {\n    var _a;\n\n    this.selectedOption = this.selectedOption = {\n      Value: context.parameters.OptionValue.raw,\n      Label: context.parameters.OptionValue.raw !== null ? ((_a = this.options.find(function (f) {\n        return f.Value === context.parameters.OptionValue.raw;\n      })) === null || _a === void 0 ? void 0 : _a.Label) || \"Unknown option:\" + context.parameters.OptionValue.raw + \" \" : \"--Select--\"\n    };\n    this.inputElement.value = \"\";\n    this.renderSelected();\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.controlValueChange = function () {\n    this.notifyOutputChangedDelegate();\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.initSearchInput = function () {\n    this.inputElement = document.createElement(\"input\");\n    this.inputElement.setAttribute(\"placeholder\", \"--Select or search option--\");\n    this.inputElement.classList.add(\"dnl-input-element\");\n    this.inputElement.addEventListener(\"keyup\", this.doSearch.bind(this));\n    this.container.append(this.inputElement);\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.initSelectedItem = function () {\n    this.selectedLabelElement = document.createElement(\"span\");\n    this.selectedLabelElement.classList.add(\"selected-label\");\n    this.selectedLabelElement.addEventListener('click', this.onClickLabel.bind(this));\n    this.container.append(this.selectedLabelElement);\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.onClickLabel = function () {\n    this.container.classList.remove(\"selected\");\n    this.inputElement.value = \"\";\n    this.inputElement.focus();\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.renderSelected = function () {\n    if (this.selectedOption.Value !== null) {\n      this.selectedLabelElement.innerHTML = this.selectedOption.Label;\n      this.selectedLabelElement.setAttribute(\"title\", this.selectedOption.Label);\n      this.container.classList.add(\"selected\");\n    } else {\n      this.container.classList.remove(\"selected\");\n      this.selectedLabelElement.innerHTML = \"---\";\n    }\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.initSearchButton = function () {\n    this.searchButton = document.createElement(\"button\");\n    this.searchButton.classList.add(\"dnl-search-btn\");\n    this.searchButton.innerHTML = \"<svg viewBox=\\\"0 0 16 16\\\" fill=\\\"currentColor\\\" xmlns=\\\"http://www.w3.org/2000/svg\\\">  <path fill-rule=\\\"evenodd\\\" d=\\\"M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z\\\"></path></svg>\";\n    this.searchButton.addEventListener('click', this.onClickFilterButton.bind(this));\n    this.container.append(this.searchButton);\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.initDropDownContainer = function () {\n    this.dropDownContainer = document.createElement(\"div\");\n    this.dropDownContainer.classList.add(\"custom-dropdown-container\");\n    this.container.append(this.dropDownContainer);\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.initEvents = function () {\n    var _this = this;\n\n    var dropDownItems = this.dropDownContainer.querySelectorAll('.custom-drop-down-item');\n\n    if (dropDownItems) {\n      dropDownItems.forEach(function (dropDownItem) {\n        dropDownItem.addEventListener(\"click\", _this.onChooseItem.bind(_this, dropDownItem));\n      });\n    }\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.onKeyPressContainer = function (event) {\n    var targetElement = event.target; //enter\n\n    if (event.keyCode == 13) {\n      if (this.container.classList.contains(\"expanded\") && this.dropDownContainer.querySelector('.custom-drop-down-item.selected')) {\n        this.onChooseItem(this.dropDownContainer.querySelector('.custom-drop-down-item.selected'));\n        event.preventDefault();\n        return;\n      }\n\n      if (targetElement.tagName === \"INPUT\" || targetElement.tagName === \"BUTTON\" && targetElement.classList.contains(\"dnl-search-btn\")) {\n        this.doSearch(null);\n        event.preventDefault();\n        return;\n      }\n    } //Esc\n\n\n    if (event.keyCode == 27) {\n      if (this.container.classList.contains(\"expanded\")) {\n        this.onClickFilterButton(event);\n      }\n    } //down\n\n\n    if (event.keyCode == 40) {\n      this.selectNextItem();\n      event.preventDefault();\n    } //up\n\n\n    if (event.keyCode == 38) {\n      this.selectPreviousItem();\n      event.preventDefault();\n    }\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.selectNextItem = function () {\n    var selectItems = this.dropDownContainer.querySelectorAll('.custom-drop-down-item');\n    var selectedItem = this.dropDownContainer.querySelector('.custom-drop-down-item.selected');\n\n    if (!selectItems || !selectItems.length || !this.container.classList.contains(\"expanded\")) {\n      return;\n    }\n\n    if (selectedItem) {\n      var currentSelectedIndex = Array.from(selectItems).indexOf(selectedItem);\n\n      if (selectItems.length > currentSelectedIndex + 1) {\n        selectItems.item(currentSelectedIndex).classList.remove(\"selected\");\n        selectItems.item(currentSelectedIndex + 1).classList.add(\"selected\");\n        this.scrollToItem(selectItems.item(currentSelectedIndex + 1));\n      }\n    } else {\n      var firstElement = selectItems.item(0);\n      firstElement.classList.add(\"selected\");\n      this.scrollToItem(firstElement);\n    }\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.selectPreviousItem = function () {\n    var selectItems = this.dropDownContainer.querySelectorAll('.custom-drop-down-item');\n    var selectedItem = this.dropDownContainer.querySelector('.custom-drop-down-item.selected');\n\n    if (!selectItems || !selectItems.length || !this.container.classList.contains(\"expanded\")) {\n      this.onClickLabel();\n      return;\n    }\n\n    if (selectedItem) {\n      var currentSelectedIndex = Array.from(selectItems).indexOf(selectedItem);\n      selectItems.item(currentSelectedIndex).classList.remove(\"selected\");\n\n      if (currentSelectedIndex > 0) {\n        selectItems.item(currentSelectedIndex - 1).classList.add(\"selected\");\n        this.scrollToItem(selectItems.item(currentSelectedIndex - 1));\n      } else {\n        this.onClickLabel();\n      }\n    }\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.scrollToItem = function (element) {\n    var divScrollable = this.dropDownContainer.querySelector(\".custom-drop-down-scrollable\");\n\n    if (divScrollable) {\n      element.focus();\n      divScrollable.scrollTop = element.offsetTop > 235 ? element.offsetTop : 0;\n    }\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.onChooseItem = function (selectedItem) {\n    var _a;\n\n    if (!selectedItem) {\n      return;\n    }\n\n    selectedItem.classList.remove(\"selected\");\n    this.hideDropDownContainer();\n    this.selectedOption = this.selectedOption = {\n      Value: +selectedItem.getAttribute(\"data-id\"),\n      Label: +selectedItem.getAttribute(\"data-id\") ? ((_a = this.options.find(function (f) {\n        return f.Value === +selectedItem.getAttribute(\"data-id\");\n      })) === null || _a === void 0 ? void 0 : _a.Label) || \"Unknown option:\" + selectedItem.getAttribute(\"data-id\") : \"\"\n    };\n    this.controlValueChange();\n    this.renderSelected();\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.onClickFilterButton = function (event) {\n    if (this.container.classList.contains(\"expanded\")) {\n      this.hideDropDownContainer();\n      this.renderSelected();\n    } else {\n      this.doSearch(null);\n      event.stopPropagation();\n    }\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.doSearch = function (event) {\n    var _this = this;\n\n    if (event && [13, 27, 9, 40, 37, 38, 39].indexOf(event.keyCode) > -1) {\n      return;\n    }\n\n    var filteredItems = this.inputElement.value.trim() ? this.options.filter(function (f) {\n      return f.Label.toLowerCase().includes(_this.inputElement.value.toLowerCase());\n    }) : this.options;\n    this.renderDropDownContainer(filteredItems);\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.renderDropDownContainer = function (optionValues) {\n    var options = \"\";\n\n    for (var v = 0; v < optionValues.length; v++) {\n      options += \"<div  data-id=\\\"\" + optionValues[v].Value + \"\\\" class=\\\"custom-drop-down-item\\\" >\\n                    <div class=\\\"option-text\\\">\\n                        <div class=\\\"option-name\\\" title=\\\"\" + optionValues[v].Label + \"\\\">\" + optionValues[v].Label + \"</div>\\n                    </div>\\n                 </div>\";\n    }\n\n    options = options.length === 0 ? \"<div class='no-data'>No data</div>\" : options;\n    this.dropDownContainer.innerHTML = \"<div class=\\\"custom-drop-down-scrollable\\\">                 \\n                 \" + options + \"                 \\n             </div>\";\n    this.initEvents();\n    this.showDropDownContainer();\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.showDropDownContainer = function () {\n    var docHeight = document.body.clientHeight;\n    var currentPosition = this.container.getBoundingClientRect().y;\n\n    if (currentPosition + 335 > docHeight) {\n      this.container.classList.add(\"expanded-top\");\n    } else {\n      this.container.classList.remove(\"expanded-top\");\n    }\n\n    this.container.classList.add(\"expanded\");\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.hideDropDownContainer = function () {\n    this.container.classList.remove(\"expanded\");\n    this.inputElement.value = \"\";\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.getOutputs = function () {\n    return {\n      OptionValue: this.selectedOption.Value || undefined\n    };\n  };\n\n  DynamicalabsPicklistWithSearch.prototype.destroy = function () {};\n\n  return DynamicalabsPicklistWithSearch;\n}();\n\nexports.DynamicalabsPicklistWithSearch = DynamicalabsPicklistWithSearch;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DynamicalabsPicklistWithSearch/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Dynamicalabs.PicklistWithSearch.DynamicalabsPicklistWithSearch', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DynamicalabsPicklistWithSearch);
} else {
	var Dynamicalabs = Dynamicalabs || {};
	Dynamicalabs.PicklistWithSearch = Dynamicalabs.PicklistWithSearch || {};
	Dynamicalabs.PicklistWithSearch.DynamicalabsPicklistWithSearch = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DynamicalabsPicklistWithSearch;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}